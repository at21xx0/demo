#include "k2.h"

int k2(int i)
{
	return i;
}



