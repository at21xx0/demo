#ifndef _K2_H__
#define _K2_H__

// 返回本身
int k2(int i);


#endif
