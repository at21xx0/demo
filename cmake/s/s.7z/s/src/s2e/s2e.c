#include <stdio.h>
#include "s2.h"

int s2e(int i) {
	return i;
}
int s2ex(int i) {
	return s2(i);
}
