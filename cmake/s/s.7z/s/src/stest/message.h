#ifndef _MESSAGE_H__
#define _MESSAGE_H__
int message(char *);

#endif
