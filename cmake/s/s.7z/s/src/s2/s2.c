#include <stdio.h>
#include "s2.h"

char *S2_VERSION = s2_VERSION; //默认定义

int s2(int i) {
	return s2e(i);
}
