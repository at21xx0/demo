
#include <stdio.h>
#include "s2.h"


int s2k(int i) {
	return s2(i);
}
