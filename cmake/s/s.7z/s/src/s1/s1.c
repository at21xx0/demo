#include <stdio.h>
#include "s1.h"

int s1(int i) {
	return i;
}
