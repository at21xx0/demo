#ifndef _S2_H__
#define _S2_H__

#include "s2Export.h"

int s2_EXPORT s2(int i);
int s2_NO_EXPORT s2k(int i);
int s2_NO_EXPORT s2e(int i);
int s2_EXPORT s2ex(int i);
extern s2_EXPORT char *S2_VERSION;

#endif
