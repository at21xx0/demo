#ifndef _S1_H__
#define _S1_H__

int s1(int i);

#endif
