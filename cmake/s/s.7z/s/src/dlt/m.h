#ifndef _M_H__
#define _M_H__
int main2(void);

#endif
