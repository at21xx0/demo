#include <windows.h>
#include <stdio.h>
#include "m.h"

int main2()
{
	// 代码没有写
	return 0;
}
