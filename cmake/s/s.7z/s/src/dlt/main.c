#include<stdio.h>
#include "m.h"

int main(void)
{
	printf("test libs2 export\n");
	return main2();
}
